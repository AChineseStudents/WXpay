package com.example.wxpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WxPayApplicationTests {

    @Test
    void contextLoads() {
    }

}
