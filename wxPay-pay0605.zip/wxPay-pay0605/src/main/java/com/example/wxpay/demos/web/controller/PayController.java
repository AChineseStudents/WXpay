package com.example.wxpay.demos.web.controller;

import com.wechat.pay.java.core.Config;
import com.wechat.pay.java.core.RSAAutoCertificateConfig;
import com.wechat.pay.java.core.exception.HttpException;
import com.wechat.pay.java.core.exception.MalformedMessageException;
import com.wechat.pay.java.core.exception.ServiceException;
import com.wechat.pay.java.service.ecommercerefund.EcommerceRefundService;
import com.wechat.pay.java.service.payments.jsapi.JsapiServiceExtension;
import com.wechat.pay.java.service.payments.jsapi.model.*;
import com.wechat.pay.java.service.payments.model.Transaction;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
@Controller
public class PayController {
    /** 商户号 */
    public static String merchantId="1715252***";//分行

    /** 商户API私钥路径 */
    public static String privateKeyPath="/root/wxPay/fenhang/apiclient_key.pem";//生产环境（分行）


    /** 商户证书序列号 */
    public static String merchantSerialNumber = "632A83543031DDFCAB9878A49158E*****";//分行

    /** 商户APIV3密钥 */
    public static String apiV3Key = "49514958572957dfjruk23******";//分行

    // 初始化商户配置
    public static Config config =
            new RSAAutoCertificateConfig.Builder()
                    .merchantId(merchantId)
                    // 使用 com.wechat.pay.java.core.util 中的函数从本地文件中加载商户私钥，商户私钥会用来生成请求的签名
                    .privateKeyFromPath(privateKeyPath)
                    .merchantSerialNumber(merchantSerialNumber)
                    .apiV3Key(apiV3Key)
                    .build();

    public static JsapiServiceExtension service;

    @RequestMapping("/pay")
    @ResponseBody
    public PrepayWithRequestPaymentResponse pay(@RequestBody PrepayRequest prepayRequest) {
        System.out.println();
        PrepayWithRequestPaymentResponse response = null;

        // 初始化服务
        service =
                new JsapiServiceExtension.Builder()
                        .config(PayController.config)
                        .signType("RSA") // 不填默认为RSA
                        .build();
        //预支付订单
        prepayRequest.setAppid("wxa054ab91ac81c900");
        prepayRequest.setMchid(PayController.merchantId);
        //填写request参数
        try {
            // ... 调用接口
            response = service.prepayWithRequestPayment(prepayRequest);
            //System.out.println(response);
        } catch (HttpException e) { // 发送HTTP请求失败
            System.out.println(e.getMessage());
            // 调用e.getHttpRequest()获取请求打印日志或上报监控，更多方法见HttpException定义
        } catch (ServiceException e) {
            // 服务返回状态小于200或大于等于300，例如500
            System.out.println(e.getResponseBody());
            // 调用e.getResponseBody()获取返回体打印日志或上报监控，更多方法见ServiceException定义
        } catch (MalformedMessageException e) { // 服务返回成功，返回体类型不合法，或者解析返回体失败
            // 调用e.getMessage()获取信息打印日志或上报监控，更多方法见MalformedMessageException定义
        }
        return response;
    }

    @RequestMapping("/queryOrderByOutTradeNo")
    @ResponseBody
    public Transaction queryOrderByOutTradeNo(@RequestBody QueryOrderByOutTradeNoRequest request){
        // 初始化服务
        service =
                new JsapiServiceExtension.Builder()
                        .config(PayController.config)
                        .signType("RSA") // 不填默认为RSA
                        .build();
        request.setMchid(PayController.merchantId);
        return service.queryOrderByOutTradeNo(request);
    }

}
