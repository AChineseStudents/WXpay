package com.example.wxpay.demos.web.controller;

import com.wechat.pay.java.core.Config;
import com.wechat.pay.java.core.RSAAutoCertificateConfig;
import com.wechat.pay.java.service.refund.RefundService;
import com.wechat.pay.java.service.refund.model.CreateRequest;
import com.wechat.pay.java.service.refund.model.QueryByOutRefundNoRequest;
import com.wechat.pay.java.service.refund.model.Refund;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class RefundController {
    /** 商户号 */
    public static String merchantId="******";//分行

    /** 商户私钥路径 */
    public static String privateKeyPath="/root/wxPay/fenhang/apiclient_key.pem";//生产环境（分行）


    /** 商户证书序列号 */
    //public static String merchantSerialNumber = "5EEA254553C90618308A8C18ACACFE222DD9EA59";
    public static String merchantSerialNumber = "632A83543031DDFCAB9878A49158E3610CE****";//分行

    /** 商户APIV3密钥 */
    //public static String apiV3Key = "kR3jSTyAgtWYJwVlGLgnUfGAV5y7y2xB";
    public static String apiV3Key = "49514958572957dfjruk23784******";//分行

    // 初始化商户配置
    public static Config config =
            new RSAAutoCertificateConfig.Builder()
                    .merchantId(merchantId)
                    // 使用 com.wechat.pay.java.core.util 中的函数从本地文件中加载商户私钥，商户私钥会用来生成请求的签名
                    .privateKeyFromPath(privateKeyPath)
                    .merchantSerialNumber(merchantSerialNumber)
                    .apiV3Key(apiV3Key)
                    .build();

    @RequestMapping("/refund")
    @ResponseBody
    public Refund refund(@RequestBody CreateRequest createRequest) {
        // 初始化服务
        RefundService service = new RefundService.Builder().config(config).build();
        return service.create(createRequest);
    }

    @RequestMapping("/getRefundOrderByOutTradeNo")
    @ResponseBody
    public Refund refundOrderByOutTradeNo(@RequestBody QueryByOutRefundNoRequest queryByOutRefundNoRequest) {
        // 初始化服务
        RefundService service = new RefundService.Builder().config(config).build();
        // queryByOutRefundNoRequest.outRefundNo="4200002660202504162939305676"
        return service.queryByOutRefundNo(queryByOutRefundNoRequest);

    }
}
